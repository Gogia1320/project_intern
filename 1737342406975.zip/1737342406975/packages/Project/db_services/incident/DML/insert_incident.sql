{
  "input" : [ {
    "id" : "j1_2",
    "text" : "inputDocList",
    "li_attr" : {
      "id" : "j1_2"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j1_2_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : true,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ {
      "id" : "j1_5",
      "text" : "type",
      "li_attr" : {
        "id" : "j1_5"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j1_5_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : false,
        "disabled" : false
      },
      "data" : {
        "guid" : "89421e32-daa1-49e3-933c-93e6e59ef968",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "string"
    }, {
      "id" : "j1_6",
      "text" : "description",
      "li_attr" : {
        "id" : "j1_6"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j1_6_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : false,
        "disabled" : false
      },
      "data" : {
        "guid" : "4b729538-e277-400d-81b4-762a5969bfe3",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "string"
    }, {
      "id" : "j1_7",
      "text" : "location",
      "li_attr" : {
        "id" : "j1_7"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j1_7_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : false,
        "disabled" : false
      },
      "data" : {
        "guid" : "29b25ce3-1573-4fa8-9f7d-6c859e107287",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "string"
    }, {
      "id" : "j1_8",
      "text" : "status",
      "li_attr" : {
        "id" : "j1_8"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j1_8_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : false,
        "disabled" : false
      },
      "data" : {
        "guid" : "204a27e0-c3aa-47c3-afdf-3c8a389e0be8",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "string"
    }, {
      "id" : "j1_9",
      "text" : "reportedByID",
      "li_attr" : {
        "id" : "j1_9"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j1_9_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : false,
        "disabled" : false
      },
      "data" : {
        "guid" : "96b7b01e-044c-4fac-b0e5-00d4ba9c425e",
        "columnType" : "-1",
        "assignList" : [ ]
      },
      "children" : [ ],
      "type" : "integer"
    } ],
    "type" : "documentList"
  }, {
    "id" : "j1_3",
    "text" : "txConn",
    "li_attr" : {
      "id" : "j1_3"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j1_3_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "javaObject"
  }, {
    "id" : "j1_4",
    "text" : "isTxn",
    "li_attr" : {
      "id" : "j1_4"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j1_4_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "boolean"
  } ],
  "output" : [ {
    "id" : "j2_1",
    "text" : "outputDocList",
    "li_attr" : {
      "id" : "j2_1"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_1_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : true,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "documentList"
  }, {
    "id" : "j2_2",
    "text" : "rows",
    "li_attr" : {
      "id" : "j2_2"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_2_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "integer"
  }, {
    "id" : "j2_3",
    "text" : "success",
    "li_attr" : {
      "id" : "j2_3"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_3_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "boolean"
  }, {
    "id" : "j2_4",
    "text" : "error",
    "li_attr" : {
      "id" : "j2_4"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_4_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "string"
  }, {
    "id" : "j2_5",
    "text" : "keys",
    "li_attr" : {
      "id" : "j2_5"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_5_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : {
      "guid" : "21c1a728-7b84-4906-b74f-98338d16f618",
      "columnType" : "-1"
    },
    "children" : [ ],
    "type" : "integerList"
  } ],
  "sql" : "aW5zZXJ0IGludG8gaW5jaWRlbnRzKHR5cGUsZGVzY3JpcHRpb24sbG9jYXRpb24sc3RhdHVzLHRpbWVzdGFtcCxyZXBvcnRlZEJ5SUQpdmFsdWVzKHt0eXBlfSx7ZGVzY3JpcHRpb259LHtsb2NhdGlvbn0se3N0YXR1c30sQ1VSUkVOVF9USU1FU1RBTVAse3JlcG9ydGVkQnlJRH0pOw==",
  "version" : "v1",
  "consumers" : "",
  "developers" : "",
  "lockedByUser" : "admin"
}