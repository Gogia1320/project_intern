{
  "input" : [ {
    "id" : "j1_2",
    "text" : "inputDocList",
    "li_attr" : {
      "id" : "j1_2"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j1_2_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : true,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "documentList"
  }, {
    "id" : "j1_3",
    "text" : "txConn",
    "li_attr" : {
      "id" : "j1_3"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j1_3_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "javaObject"
  }, {
    "id" : "j1_4",
    "text" : "isTxn",
    "li_attr" : {
      "id" : "j1_4"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j1_4_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "boolean"
  } ],
  "output" : [ {
    "id" : "j2_1",
    "text" : "outputDocList",
    "li_attr" : {
      "id" : "j2_1"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_1_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : true,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ {
      "id" : "j2_5",
      "text" : "IncidentID",
      "li_attr" : {
        "id" : "j2_5"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j2_5_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : false,
        "disabled" : false
      },
      "data" : {
        "guid" : "94dd78e0-6d9a-4207-84e3-5c89d532b736",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "integer"
    }, {
      "id" : "j2_6",
      "text" : "type",
      "li_attr" : {
        "id" : "j2_6"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j2_6_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : false,
        "disabled" : false
      },
      "data" : {
        "guid" : "8e1097d8-20c4-4ba5-8ae5-33240cf7d063",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "string"
    }, {
      "id" : "j2_7",
      "text" : "description",
      "li_attr" : {
        "id" : "j2_7"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j2_7_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : false,
        "disabled" : false
      },
      "data" : {
        "guid" : "9b815005-5199-41f9-84aa-5dddc530b8f8",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "string"
    }, {
      "id" : "j2_8",
      "text" : "location",
      "li_attr" : {
        "id" : "j2_8"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j2_8_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : false,
        "disabled" : false
      },
      "data" : {
        "guid" : "7d7b4128-ceb2-4526-86c4-09f1801ddc79",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "string"
    }, {
      "id" : "j2_9",
      "text" : "status",
      "li_attr" : {
        "id" : "j2_9"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j2_9_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : false,
        "disabled" : false
      },
      "data" : {
        "guid" : "225e73ef-4fb2-4592-a277-0dc5819b12d4",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "string"
    }, {
      "id" : "j2_10",
      "text" : "reportedByID",
      "li_attr" : {
        "id" : "j2_10"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j2_10_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : true,
        "disabled" : false
      },
      "data" : {
        "guid" : "5fb5d523-ba0a-4a38-b8dc-3ac003eec6a6",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "integer"
    } ],
    "type" : "documentList"
  }, {
    "id" : "j2_2",
    "text" : "rows",
    "li_attr" : {
      "id" : "j2_2"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_2_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "integer"
  }, {
    "id" : "j2_3",
    "text" : "success",
    "li_attr" : {
      "id" : "j2_3"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_3_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "boolean"
  }, {
    "id" : "j2_4",
    "text" : "error",
    "li_attr" : {
      "id" : "j2_4"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_4_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "string"
  } ],
  "sql" : "c2VsZWN0IEluY2lkZW50SUQsdHlwZSxkZXNjcmlwdGlvbixsb2NhdGlvbixzdGF0dXMsVGltZXN0YW1wLHJlcG9ydGVkQnlJRCBmcm9tIGluY2lkZW50czs=",
  "version" : "v1",
  "consumers" : "",
  "developers" : "",
  "lockedByUser" : "admin"
}