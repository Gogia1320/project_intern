{
  "input" : [ {
    "id" : "j1_2",
    "text" : "inputDocList",
    "li_attr" : {
      "id" : "j1_2"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j1_2_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : true,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ {
      "id" : "j1_5",
      "text" : "email",
      "li_attr" : {
        "id" : "j1_5"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j1_5_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : false,
        "disabled" : false
      },
      "data" : {
        "guid" : "edd0645b-5c01-4450-8dac-c729d4d61518",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "string"
    }, {
      "id" : "j1_6",
      "text" : "password",
      "li_attr" : {
        "id" : "j1_6"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j1_6_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : true,
        "disabled" : false
      },
      "data" : {
        "guid" : "fe7610f6-54cf-420f-ab23-a59c424cebba",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "string"
    } ],
    "type" : "documentList"
  }, {
    "id" : "j1_3",
    "text" : "txConn",
    "li_attr" : {
      "id" : "j1_3"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j1_3_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "javaObject"
  }, {
    "id" : "j1_4",
    "text" : "isTxn",
    "li_attr" : {
      "id" : "j1_4"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j1_4_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "boolean"
  } ],
  "output" : [ {
    "id" : "j2_1",
    "text" : "outputDocList",
    "li_attr" : {
      "id" : "j2_1"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_1_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "documentList"
  }, {
    "id" : "j2_2",
    "text" : "rows",
    "li_attr" : {
      "id" : "j2_2"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_2_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "integer"
  }, {
    "id" : "j2_3",
    "text" : "success",
    "li_attr" : {
      "id" : "j2_3"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_3_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "boolean"
  }, {
    "id" : "j2_4",
    "text" : "error",
    "li_attr" : {
      "id" : "j2_4"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_4_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "string"
  } ],
  "sql" : "U0VMRUNUICogRlJPTSBVc2VycyBXSEVSRSBlbWFpbCA9IHtlbWFpbH0gQU5EIHBhc3N3b3JkID0ge3Bhc3N3b3JkfTs=",
  "version" : "v1",
  "consumers" : "",
  "developers" : "developers",
  "lockedByUser" : "admin"
}