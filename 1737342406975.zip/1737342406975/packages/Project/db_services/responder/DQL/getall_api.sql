{
  "input" : [ {
    "id" : "j1_2",
    "text" : "inputDocList",
    "li_attr" : {
      "id" : "j1_2"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j1_2_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : true,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "documentList"
  }, {
    "id" : "j1_3",
    "text" : "txConn",
    "li_attr" : {
      "id" : "j1_3"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j1_3_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "javaObject"
  }, {
    "id" : "j1_4",
    "text" : "isTxn",
    "li_attr" : {
      "id" : "j1_4"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j1_4_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "boolean"
  } ],
  "output" : [ {
    "id" : "j2_1",
    "text" : "outputDocList",
    "li_attr" : {
      "id" : "j2_1"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_1_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : true,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ {
      "id" : "j2_5",
      "text" : "name",
      "li_attr" : {
        "id" : "j2_5"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j2_5_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : false,
        "disabled" : false
      },
      "data" : {
        "guid" : "1e475854-a29a-4379-a55d-75a87575bb9e",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "string"
    }, {
      "id" : "j2_6",
      "text" : "role",
      "li_attr" : {
        "id" : "j2_6"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j2_6_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : false,
        "disabled" : false
      },
      "data" : {
        "guid" : "7fa2f5bb-3d6c-47a8-9758-57dff08ca382",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "string"
    }, {
      "id" : "j2_7",
      "text" : "phone",
      "li_attr" : {
        "id" : "j2_7"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j2_7_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : false,
        "disabled" : false
      },
      "data" : {
        "guid" : "7ca2580d-be13-461b-a9b9-e7d2d9ec9d98",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "string"
    }, {
      "id" : "j2_8",
      "text" : "location",
      "li_attr" : {
        "id" : "j2_8"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j2_8_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : true,
        "disabled" : false
      },
      "data" : {
        "guid" : "72a7bc57-b1d5-48a2-b1d3-8744c4a71038",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "string"
    } ],
    "type" : "documentList"
  }, {
    "id" : "j2_2",
    "text" : "rows",
    "li_attr" : {
      "id" : "j2_2"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_2_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "integer"
  }, {
    "id" : "j2_3",
    "text" : "success",
    "li_attr" : {
      "id" : "j2_3"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_3_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "boolean"
  }, {
    "id" : "j2_4",
    "text" : "error",
    "li_attr" : {
      "id" : "j2_4"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_4_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "string"
  } ],
  "sql" : "c2VsZWN0IG5hbWUscm9sZSxwaG9uZSxsb2NhdGlvbiBmcm9tIHJlc3BvbmRlcnM7",
  "version" : "v1",
  "consumers" : "",
  "developers" : "developers",
  "lockedByUser" : "admin"
}