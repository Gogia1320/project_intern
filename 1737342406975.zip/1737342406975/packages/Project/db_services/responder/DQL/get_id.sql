{
  "input" : [ {
    "id" : "j1_2",
    "text" : "inputDocList",
    "li_attr" : {
      "id" : "j1_2"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j1_2_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : true,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ {
      "id" : "j1_5",
      "text" : "id",
      "li_attr" : {
        "id" : "j1_5"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j1_5_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : true,
        "disabled" : false
      },
      "data" : {
        "guid" : "369716ce-30bc-4f86-ac13-c06059d54007",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "integer"
    } ],
    "type" : "documentList"
  }, {
    "id" : "j1_3",
    "text" : "txConn",
    "li_attr" : {
      "id" : "j1_3"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j1_3_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "javaObject"
  }, {
    "id" : "j1_4",
    "text" : "isTxn",
    "li_attr" : {
      "id" : "j1_4"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j1_4_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "boolean"
  } ],
  "output" : [ {
    "id" : "j2_1",
    "text" : "outputDocList",
    "li_attr" : {
      "id" : "j2_1"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_1_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : true,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ {
      "id" : "j2_5",
      "text" : "location",
      "li_attr" : {
        "id" : "j2_5"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j2_5_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : false,
        "disabled" : false
      },
      "data" : {
        "guid" : "6c7b2f51-003d-4b21-af6c-b8ba86f0afb4",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "string"
    }, {
      "id" : "j2_6",
      "text" : "id",
      "li_attr" : {
        "id" : "j2_6"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j2_6_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : true,
        "disabled" : false
      },
      "data" : {
        "guid" : "bf190acf-7739-42fa-8a52-c6125524b91b",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "integer"
    } ],
    "type" : "documentList"
  }, {
    "id" : "j2_2",
    "text" : "rows",
    "li_attr" : {
      "id" : "j2_2"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_2_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "integer"
  }, {
    "id" : "j2_3",
    "text" : "success",
    "li_attr" : {
      "id" : "j2_3"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_3_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "boolean"
  }, {
    "id" : "j2_4",
    "text" : "error",
    "li_attr" : {
      "id" : "j2_4"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_4_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "string"
  } ],
  "sql" : "c2VsZWN0IGxvY2F0aW9uIGZyb20gcmVzcG9uZGVycyB3aGVyZSBSZXNwb25kZXJJRCA9IHtpZH07",
  "version" : "v1",
  "consumers" : "",
  "developers" : "",
  "lockedByUser" : "admin"
}