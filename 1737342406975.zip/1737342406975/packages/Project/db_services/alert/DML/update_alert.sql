{
  "input" : [ {
    "id" : "j1_2",
    "text" : "inputDocList",
    "li_attr" : {
      "id" : "j1_2"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j1_2_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : true,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ {
      "id" : "j1_5",
      "text" : "Status",
      "li_attr" : {
        "id" : "j1_5"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j1_5_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : false,
        "disabled" : false
      },
      "data" : {
        "guid" : "48eaea3b-3746-4492-8a66-a9570f063676",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "string"
    }, {
      "id" : "j1_6",
      "text" : "AlertID",
      "li_attr" : {
        "id" : "j1_6"
      },
      "a_attr" : {
        "href" : "#",
        "id" : "j1_6_anchor"
      },
      "state" : {
        "loaded" : true,
        "opened" : false,
        "selected" : false,
        "disabled" : false
      },
      "data" : {
        "guid" : "5c119b95-09aa-4575-b47b-04ccfb4597e6",
        "columnType" : "-1"
      },
      "children" : [ ],
      "type" : "integer"
    } ],
    "type" : "documentList"
  }, {
    "id" : "j1_3",
    "text" : "txConn",
    "li_attr" : {
      "id" : "j1_3"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j1_3_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "javaObject"
  }, {
    "id" : "j1_4",
    "text" : "isTxn",
    "li_attr" : {
      "id" : "j1_4"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j1_4_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "boolean"
  } ],
  "output" : [ {
    "id" : "j2_1",
    "text" : "outputDocList",
    "li_attr" : {
      "id" : "j2_1"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_1_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "documentList"
  }, {
    "id" : "j2_2",
    "text" : "rows",
    "li_attr" : {
      "id" : "j2_2"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_2_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "integer"
  }, {
    "id" : "j2_3",
    "text" : "success",
    "li_attr" : {
      "id" : "j2_3"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_3_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "boolean"
  }, {
    "id" : "j2_4",
    "text" : "error",
    "li_attr" : {
      "id" : "j2_4"
    },
    "a_attr" : {
      "href" : "#",
      "id" : "j2_4_anchor"
    },
    "state" : {
      "loaded" : true,
      "opened" : false,
      "selected" : false,
      "disabled" : false,
      "hidden" : false
    },
    "data" : { },
    "children" : [ ],
    "type" : "string"
  } ],
  "sql" : "dXBkYXRlIGFsZXJ0cyBzZXQgU3RhdHVzID0ge1N0YXR1c30sVGltZXN0YW1wID0gQ1VSUkVOVF9USU1FU1RBTVAgd2hlcmUgQWxlcnRJRCA9IHtBbGVydElEfTs=",
  "version" : "v1",
  "consumers" : "",
  "developers" : "",
  "lockedByUser" : "admin"
}